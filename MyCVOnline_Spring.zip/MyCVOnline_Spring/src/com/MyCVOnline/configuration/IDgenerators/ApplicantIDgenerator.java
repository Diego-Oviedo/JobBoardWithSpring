package com.MyCVOnline.configuration.IDgenerators;

public class ApplicantIDgenerator {

}
